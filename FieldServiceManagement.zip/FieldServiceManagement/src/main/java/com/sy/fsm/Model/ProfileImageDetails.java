package com.sy.fsm.Model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "profile_image_details")
public class ProfileImageDetails	 {
	
	@Id
	@Column(name = "id")
	@JsonProperty("ID")
	public String id;
	
	@Column(name = "file_path")
	@JsonProperty("File Path")
	public String filePath;
	
	@Column(name = "file_name")
	@JsonProperty("File Name")
	public String fileName;
	
	@Column(name = "file_type")
	@JsonProperty("File Type")
	public String fileType;
	
	@Column(name = "profile_type")
	@JsonProperty("Profile Type")
	public String profileType;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	public ProfileImageDetails(String id, String filePath, String fileName, String fileType, String profileType) {
		super();
		this.id = id;
		this.filePath = filePath;
		this.fileName = fileName;
		this.fileType = fileType;
		this.profileType = profileType;
	}

	public ProfileImageDetails() {
		super();
	}
	
	
}
