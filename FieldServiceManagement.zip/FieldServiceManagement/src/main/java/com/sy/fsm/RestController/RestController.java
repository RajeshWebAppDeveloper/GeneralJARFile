package com.sy.fsm.RestController;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.sy.fsm.Model.CategoryDetails;
import com.sy.fsm.Model.DarDetails;
import com.sy.fsm.Model.DarExpensesDetails;
import com.sy.fsm.Model.EstimationDetails;
import com.sy.fsm.Model.EstimationProductDetails;
import com.sy.fsm.Model.OrderDetails;
import com.sy.fsm.Model.OrderProductDetails;
import com.sy.fsm.Model.ProductDetails;
import com.sy.fsm.Repository.CategoryDetailsRepository;
import com.sy.fsm.Repository.DarDetailsRepository;
import com.sy.fsm.Repository.DarExpensesDetailsRepository;
import com.sy.fsm.Repository.EstimationDetailsRepository;
import com.sy.fsm.Repository.EstimationProductDetailsRepository;
import com.sy.fsm.Repository.OrderDetailsRepository;
import com.sy.fsm.Repository.OrderProductDetailsRepository;
import com.sy.fsm.Repository.ProductDetailsRepository;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;


@org.springframework.web.bind.annotation.RestController
public class RestController {
	
	@Value("${upload.dir}")
    private String UPLOAD_DIR;
	
	@Autowired
	CategoryDetailsRepository categoryDetailsRepository;
	
	@Autowired
	ProductDetailsRepository productDetailsRepository;
	
	@Autowired
	DarDetailsRepository darDetailsRepository;
	
	@Autowired
	DarExpensesDetailsRepository darExpensesDetailsRepository;
	
	@Autowired
	EstimationDetailsRepository estimationDetailsRepository;
	
	@Autowired
	EstimationProductDetailsRepository estimationProductDetailsRepository;
	
	@Autowired
	OrderDetailsRepository orderDetailsRepository;
	
	@Autowired
	OrderProductDetailsRepository orderProductDetailsRepository;
	
	
        
    
    @RequestMapping(value = "/fsm/getCategoryDetailsList", method = RequestMethod.POST, consumes="application/json")
	public String getCategoryDetailsList(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/getCategoryDetailsList:::::::");
			JSONObject jObj = new JSONObject(payload);
			String id = jObj.getString("ID");
			System.out.println(id);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			ObjectMapper mapper = new ObjectMapper();
			List<CategoryDetails> propertiesList = categoryDetailsRepository.findAll();
			mapper.setDateFormat(sdf);
			String sourceString = mapper.writeValueAsString(propertiesList);
			vResponse = "{\"status\":\"true\",\"data\":"+sourceString+"}";
			System.out.println(sourceString);
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
    
    /******************************************************update****************************************************/
	@RequestMapping(value = "/fsm/updateCategoryDetails", method = RequestMethod.POST, consumes = "application/json")
	public String updateCategoryDetails(@RequestBody String payload) {
	    String vResponse = "{\"status\":\"false\"}";
	    try {
	        System.out.println("/fsm/updateCategoryDetails:::::::" + payload);	        
	        ObjectMapper mapper = new ObjectMapper();
	        CategoryDetails newDetails = mapper.readValue(payload, CategoryDetails.class);	        
	        UUID id = newDetails.getId();
	        if (id != null) {	            
	            Optional<CategoryDetails> existingRecord = categoryDetailsRepository.findById(id);
	            if (existingRecord.isPresent()) {	                
	            	CategoryDetails categoryDetails = existingRecord.get();
	            	categoryDetails.setCategoryID(newDetails.getCategoryID());
	            	categoryDetails.setCategory(newDetails.getCategory());
	            	categoryDetails.setCreatedDate(newDetails.getCreatedDate());
	            	categoryDetails.setCreatedBy(newDetails.getCreatedBy());	            		               
	            	categoryDetailsRepository.save(categoryDetails);
	                vResponse = "{\"status\":\"true\"}";
	            }
	        } else {
	        	newDetails.setId(UUID.randomUUID());
	        	newDetails.setCategoryID(categoryDetailsRepository.generateCategorySequence());
	        	categoryDetailsRepository.save(newDetails);
	            vResponse = "{\"status\":\"true\"}";
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
	    }
	    System.out.println("VResponse :::" + vResponse);
	    return vResponse;
	}
	@RequestMapping(value = "/fsm/editCategoryDetails", method = RequestMethod.POST, consumes="application/json")
	public String editCategoryDetails(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/editCategoryDetails::::::::::::::::"+payload);			
			JSONObject jObj = new JSONObject(payload);
			String idString = jObj.getString("ID");	
			UUID id = UUID.fromString(idString);
			Optional<CategoryDetails> existingDetailsRecord = categoryDetailsRepository.findById(id);
			if(existingDetailsRecord.isPresent()) {
				CategoryDetails categoryDetails = existingDetailsRecord.get();
				ObjectMapper mapper = new ObjectMapper();
				String sourceString = mapper.writeValueAsString(categoryDetails);
				vResponse =  "{\"status\":\"true\",\"data\":"+sourceString+"}";	            
			}else {
				vResponse =  "{\"status\":\"false\"}";
			}										
			System.out.println(vResponse);
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
	@RequestMapping(value = "/fsm/deleteCategoryDetails", method = RequestMethod.POST, consumes="application/json")
	public String deleteCategoryDetails(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/deleteCategoryDetails::::::::::"+payload);
			JSONObject jObj = new JSONObject(payload);
			String idString = jObj.getString("ID");			
			UUID id = UUID.fromString(idString);			
			Optional<CategoryDetails> existingDetailsRecord = categoryDetailsRepository.findById(id);			
			if(existingDetailsRecord.isPresent()){					
				CategoryDetails categoryDetails = existingDetailsRecord.get();
				categoryDetailsRepository.delete(categoryDetails);									
				vResponse =  "{\"status\":\"true\"}";
			}
			System.out.println("vResponse::::"+vResponse);
		}catch(Exception e4) {
			e4.printStackTrace();			
		}
	    return vResponse;
	}
	
	@RequestMapping(value = "/fsm/getProductDetailsList", method = RequestMethod.POST, consumes="application/json")
	public String getProductDetailsList(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/getProductDetailsList:::::::");
			JSONObject jObj = new JSONObject(payload);
			String id = jObj.getString("ID");
			System.out.println(id);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			ObjectMapper mapper = new ObjectMapper();
			List<ProductDetails> productList = productDetailsRepository.findAll();
			mapper.setDateFormat(sdf);
			String sourceString = mapper.writeValueAsString(productList);
			vResponse = "{\"status\":\"true\",\"data\":"+sourceString+"}";
			System.out.println(sourceString);
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
	@RequestMapping(value = "/fsm/getProductDetailsBasedOnProductName", method = RequestMethod.POST, consumes="application/json")
	public String getProductDetailsBasedOnProductName(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/getProductDetailsBasedOnProductName:::::::");
			JSONObject jObj = new JSONObject(payload);
			String productName = jObj.getString("ProductName");
			System.out.println(productName);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			ObjectMapper mapper = new ObjectMapper();
			Optional<ProductDetails> productRecord= productDetailsRepository.findByProductName(productName);
			if(productRecord.isPresent()) {
				ProductDetails productDetails = productRecord.get();
				mapper.setDateFormat(sdf);
				String sourceString = mapper.writeValueAsString(productDetails);
				vResponse = "{\"status\":\"true\",\"data\":"+sourceString+"}";
				System.out.println(sourceString);
			}			
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
	@RequestMapping(value = "/fsm/getProductDetailsBasedOnProductID", method = RequestMethod.POST, consumes="application/json")
	public String getProductDetailsBasedOnProductID(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/getProductDetailsBasedOnProductID:::::::");
			JSONObject jObj = new JSONObject(payload);
			String productID = jObj.getString("ProductID");
			System.out.println(productID);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			ObjectMapper mapper = new ObjectMapper();
			Optional<ProductDetails> productRecord= productDetailsRepository.findByProductId(productID);
			if(productRecord.isPresent()) {
				ProductDetails productDetails = productRecord.get();
				mapper.setDateFormat(sdf);
				String sourceString = mapper.writeValueAsString(productDetails);
				vResponse = "{\"status\":\"true\",\"data\":"+sourceString+"}";
				System.out.println(sourceString);
			}			
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
	/******************************************************update****************************************************/
	@RequestMapping(value = "/fsm/updateProductDetails", method = RequestMethod.POST, consumes = "application/json")
	public String updateProductDetails(@RequestBody String payload) {
	    String vResponse = "{\"status\":\"false\"}";
	    try {
	        System.out.println("/fsm/updateProductDetails:::::::" + payload);	        
	        ObjectMapper mapper = new ObjectMapper();
	        ProductDetails newDetails = mapper.readValue(payload, ProductDetails.class);	        
	        UUID id = newDetails.getId();
	        if (id != null) {	            
	            Optional<ProductDetails> existingRecord = productDetailsRepository.findById(id);
	            if (existingRecord.isPresent()) {	                
	            	ProductDetails productDetails = existingRecord.get();
	            	productDetails.setProductID(newDetails.getProductID());
	            	productDetails.setProductName(newDetails.getProductName());
	            	productDetails.setProductCategory(newDetails.getProductCategory());
	            	productDetails.setUnitPrice(newDetails.getUnitPrice());
	            	productDetails.setTax(newDetails.getTax());
	            	productDetails.setCreatedDate(newDetails.getCreatedDate());
	            	productDetails.setCreatedBy(newDetails.getCreatedBy());	            		               
	            	productDetailsRepository.save(productDetails);
	                vResponse = "{\"status\":\"true\"}";
	            }
	        } else {
	        	newDetails.setId(UUID.randomUUID());
	        	newDetails.setProductID(productDetailsRepository.generateProductSequence());
	        	productDetailsRepository.save(newDetails);
	            vResponse = "{\"status\":\"true\"}";
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
	    }
	    System.out.println("VResponse :::" + vResponse);
	    return vResponse;
	}
	
	@RequestMapping(value = "/fsm/editProductDetails", method = RequestMethod.POST, consumes="application/json")
	public String editProductDetails(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/editProductDetails::::::::::::::::"+payload);			
			JSONObject jObj = new JSONObject(payload);
			String idString = jObj.getString("ID");	
			UUID id = UUID.fromString(idString);
			Optional<ProductDetails> existingDetailsRecord = productDetailsRepository.findById(id);
			if(existingDetailsRecord.isPresent()) {
				ProductDetails productDetails = existingDetailsRecord.get();
				ObjectMapper mapper = new ObjectMapper();
				String sourceString = mapper.writeValueAsString(productDetails);
				vResponse =  "{\"status\":\"true\",\"data\":"+sourceString+"}";	            
			}else {
				vResponse =  "{\"status\":\"false\"}";
			}										
			System.out.println(vResponse);
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
	@RequestMapping(value = "/fsm/deleteProductDetails", method = RequestMethod.POST, consumes="application/json")
	public String deleteProductDetails(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/deleteProductDetails::::::::::"+payload);
			JSONObject jObj = new JSONObject(payload);
			String idString = jObj.getString("ID");			
			UUID id = UUID.fromString(idString);			
			Optional<ProductDetails> existingDetailsRecord = productDetailsRepository.findById(id);			
			if(existingDetailsRecord.isPresent()){					
				ProductDetails productDetails = existingDetailsRecord.get();
				productDetailsRepository.delete(productDetails);									
				vResponse =  "{\"status\":\"true\"}";
			}
			System.out.println("vResponse::::"+vResponse);
		}catch(Exception e4) {
			e4.printStackTrace();			
		}
	    return vResponse;
	}
	
	@RequestMapping(value = "/fsm/getDarDetailsList", method = RequestMethod.POST, consumes="application/json")
	public String getDarDetailsList(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/getDarDetailsList:::::::");
			JSONObject jObj = new JSONObject(payload);
			String id = jObj.getString("ID");
			System.out.println(id);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			ObjectMapper mapper = new ObjectMapper();
			List<DarDetails> detailsList = darDetailsRepository.findAll();
			mapper.setDateFormat(sdf);
			String sourceString = mapper.writeValueAsString(detailsList);
			vResponse = "{\"status\":\"true\",\"data\":"+sourceString+"}";
			System.out.println(sourceString);
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
	
	@RequestMapping(value = "/fsm/generateUUID", method = RequestMethod.POST, consumes = "application/json")
	public String generateUUID(@RequestBody String payload) {
	    String vResponse = "{\"status\":\"false\"}";
	    try {
	    	System.out.println("/fsm/generateUUID:::::::");	        	        
	    	vResponse =  "{\"status\":\"true\",\"id\":\""+UUID.randomUUID().toString()+"\"}";
			}catch(Exception e) {
				e.printStackTrace();
				vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
			}
			System.out.println("VResponse :::" + vResponse);
			return vResponse;
		}
	/******************************************************update****************************************************/
	@RequestMapping(value = "/fsm/updateDarDetails", method = RequestMethod.POST, consumes = "application/json")
	public String updateDarDetails(@RequestBody String payload) {
	    String vResponse = "{\"status\":\"false\"}";
	    try {
	        System.out.println("/fsm/updateDarDetails:::::::" + payload);	        
	        ObjectMapper mapper = new ObjectMapper();
	        DarDetails newDetails = mapper.readValue(payload, DarDetails.class);	        
	        UUID id = newDetails.getId();	        
	        if (!newDetails.getDarNO().equalsIgnoreCase("")) {	            
	            Optional<DarDetails> existingRecord = darDetailsRepository.findById(id);
	            if (existingRecord.isPresent()) {	  
	            	System.out.println("existingRecord");
	            	DarDetails darDetails = existingRecord.get();
	            	darDetails.setDarNO(newDetails.getDarNO());
	            	darDetails.setDarProcessDate(newDetails.getDarProcessDate());
	            	darDetails.setPlannedActivity(newDetails.getPlannedActivity());
	            	darDetails.setDeliveryPlaceNameAndAddress(newDetails.getDeliveryPlaceNameAndAddress());
	            	darDetails.setStateCumArea(newDetails.getStateCumArea());
	            	darDetails.setClientName(newDetails.getClientName());
	            	darDetails.setClientMobileNO(newDetails.getClientName());
	            	darDetails.setAboutTheClient(newDetails.getClientMobileNO());
	            	darDetails.setProductDetails(newDetails.getProductDetails());
	            	darDetails.setFromLocation(newDetails.getFromLocation());
	            	darDetails.setToLocation(newDetails.getToLocation());
	            	darDetails.setTotalExpenses(newDetails.getTotalExpenses());
	            	darDetails.setStatusToVisit(newDetails.getStatusToVisit());
	            	darDetails.setCreatedDate(newDetails.getCreatedDate());
	            	darDetails.setCreatedBy(newDetails.getCreatedBy());	            	
	            	darDetailsRepository.save(darDetails);
	                vResponse = "{\"status\":\"true\"}";
	            }
	        } else {
	        	System.out.println("newRecord");
	        	newDetails.setId(id);
	        	newDetails.setDarNO(darDetailsRepository.generateDarSequence());
	        	darDetailsRepository.save(newDetails);
	            vResponse = "{\"status\":\"true\"}";
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
	    }
	    System.out.println("VResponse :::" + vResponse);
	    return vResponse;
	}
	
	@RequestMapping(value = "/fsm/editDarDetails", method = RequestMethod.POST, consumes="application/json")
	public String editDarDetails(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/editDarDetails::::::::::::::::"+payload);			
			JSONObject jObj = new JSONObject(payload);
			String idString = jObj.getString("ID");	
			UUID id = UUID.fromString(idString);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Optional<DarDetails> existingDetailsRecord = darDetailsRepository.findById(id);
			if(existingDetailsRecord.isPresent()) {
				DarDetails darDetails = existingDetailsRecord.get();
				ObjectMapper mapper = new ObjectMapper();
				mapper.setDateFormat(sdf);
				String sourceString = mapper.writeValueAsString(darDetails);
				List<DarExpensesDetails> expenseDetailsList = darExpensesDetailsRepository.findByReferenceId(id.toString());
				String expenseDetailsSourceString = mapper.writeValueAsString(expenseDetailsList);				
				vResponse =  "{\"status\":\"true\",\"data\":"+sourceString+",\"expensesData\":"+expenseDetailsSourceString+"}";	            
			}else {
				vResponse =  "{\"status\":\"false\"}";
			}										
			System.out.println(vResponse);
		}catch(Exception e4) {
			e4.printStackTrace();
		}
	    return vResponse;
	}
	
	@RequestMapping(value = "/fsm/deleteDarDetails", method = RequestMethod.POST, consumes="application/json")
	public String deleteDarDetails(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/deleteProductDetails::::::::::"+payload);
			JSONObject jObj = new JSONObject(payload);
			String idString = jObj.getString("ID");			
			UUID id = UUID.fromString(idString);			
			Optional<DarDetails> existingDetailsRecord = darDetailsRepository.findById(id);			
			if(existingDetailsRecord.isPresent()){					
				DarDetails darDetails = existingDetailsRecord.get();
				darDetailsRepository.delete(darDetails);	
				
				List<DarExpensesDetails> expenseDetailsList = darExpensesDetailsRepository.findByReferenceId(id.toString());
				if(expenseDetailsList.size() > 0) {
					darExpensesDetailsRepository.deleteAll(expenseDetailsList);
				}
				vResponse =  "{\"status\":\"true\"}";
			}
			System.out.println("vResponse::::"+vResponse);
		}catch(Exception e4) {
			e4.printStackTrace();			
		}
	    return vResponse;
	}
	
	
	 @PostMapping("/fsm/updateDarExpensesDetails")
	    public ResponseEntity<Map<String, String>> uploadExpenses(
	            @RequestParam("expenses") String expensesJson,
	            @RequestParam("imageFiles") List<MultipartFile> imageFiles) { 
		 String vResponse =  "{\"status\":\"false\"}";
		 Map<String, String> response = new HashMap<>();
	        try {
	        	System.out.println("/fsm/updateDarExpensesDetails>>>>::::"+expensesJson);
	            ObjectMapper objectMapper = new ObjectMapper();
	            List<DarExpensesDetails> expensesList = objectMapper.readValue(expensesJson, 
	                new TypeReference<List<DarExpensesDetails>>() {});
	            System.out.println("expensesList>>>>::::"+expensesList.size());
	            for (int i = 0; i < expensesList.size(); i++) {
	                DarExpensesDetails expense = expensesList.get(i);
	                MultipartFile imageFile = imageFiles.get(i);
	                System.out.println("/file>>>>::::::::::"+imageFiles.get(i));
	                if (imageFile != null && !imageFile.isEmpty()) {	                   
	                    String fileName = imageFile.getOriginalFilename();	                   
	                    File file = new File(UPLOAD_DIR, fileName);
	                    imageFile.transferTo(file);
	
	                    expense.setImageFilePath(fileName);
	                    
	                }
	                if(expense.getId() != null) {
	                	Optional<DarExpensesDetails> expenseDetailsRecord = darExpensesDetailsRepository.findById(expense.getId());
		                if(expenseDetailsRecord.isPresent()) {
		                	DarExpensesDetails expenseDetails = expenseDetailsRecord.get();
		                	expenseDetails.setExpensesAmount(expense.getExpensesAmount());
			            	expenseDetails.setExpensesDescription(expense.getExpensesDescription());	            
			            	expenseDetails.setReferenceId(expense.getReferenceId());
			            	darExpensesDetailsRepository.save(expense);
			            }
	                }else {
		            	expense.setId(UUID.randomUUID());		            
			            darExpensesDetailsRepository.save(expense);
		            }	            
	            }
	            vResponse =  "{\"status\":\"true\"}";
	            System.out.println("vResponse::::"+vResponse);
	            
	            response.put("status", "true");
	            response.put("message", "User details updated successfully.");
	            return ResponseEntity.ok(response);

	        } catch (Exception e) {
	            e.printStackTrace();
	            response.put("status", "false");
	            response.put("error", "File upload failed: " + e.getMessage());
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	        }
	    }
	 
	 
	 	@GetMapping("/fsm/RetrieveFile/{fileName}")
	    public ResponseEntity<byte[]> getFile(@PathVariable String fileName) throws IOException {
	        Path path = Paths.get(UPLOAD_DIR + fileName);
	        byte[] fileBytes = Files.readAllBytes(path);

	        return ResponseEntity.ok()
	                .header("Content-Type", Files.probeContentType(path))
	                .body(fileBytes);
	    }
	    
	    @RequestMapping(value = "/fsm/deleteDarExpensesDetails", method = RequestMethod.POST, consumes="application/json")
		public String deleteDarExpensesDetails(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/deleteDarExpensesDetails::::::::::"+payload);
				JSONObject jObj = new JSONObject(payload);
				String idString = jObj.getString("ID");			
				UUID id = UUID.fromString(idString);			
				Optional<DarExpensesDetails> expenseDetailsRecord = darExpensesDetailsRepository.findById(id);			
				if(expenseDetailsRecord.isPresent()){					
					DarExpensesDetails expenseDetails = expenseDetailsRecord.get();
					darExpensesDetailsRepository.delete(expenseDetails);	
					
					List<DarExpensesDetails> expenseDetailsList = darExpensesDetailsRepository.findByReferenceId(id.toString());
					if(expenseDetailsList.size() > 0) {
						darExpensesDetailsRepository.deleteAll(expenseDetailsList);
					}
					vResponse =  "{\"status\":\"true\"}";
				}
				System.out.println("vResponse::::"+vResponse);
			}catch(Exception e4) {
				e4.printStackTrace();			
			}
		    return vResponse;
		}
	    
	    @RequestMapping(value = "/fsm/getEstimationDetailsList", method = RequestMethod.POST, consumes="application/json")
		public String getEstimationDetailsList(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/getEstimationDetailsList:::::::");
				JSONObject jObj = new JSONObject(payload);
				String id = jObj.getString("ID");
				System.out.println(id);
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
				ObjectMapper mapper = new ObjectMapper();
				List<EstimationDetails> detailsList = estimationDetailsRepository.findAll();
				mapper.setDateFormat(sdf);
				String sourceString = mapper.writeValueAsString(detailsList);
				vResponse = "{\"status\":\"true\",\"data\":"+sourceString+"}";
				System.out.println(sourceString);
			}catch(Exception e4) {
				e4.printStackTrace();
			}
		    return vResponse;
		}
	    
	    /******************************************************update****************************************************/
	    @RequestMapping(value = "/fsm/updateEstimationDetails", method = RequestMethod.POST, consumes = "application/json")
	    public String updateEstimationDetails(@RequestBody String payload) {
	        String vResponse = "{\"status\":\"false\"}";
	        try {
	            System.out.println("/fsm/updateEstimationDetails:::::::" + payload);	        
	            ObjectMapper mapper = new ObjectMapper();
	            EstimationDetails newDetails = mapper.readValue(payload, EstimationDetails.class);
	            
	            UUID id = newDetails.getId(); // Ensure this ID is correctly passed in the payload
	            
	            if (newDetails.getEstNO() != null && !newDetails.getEstNO().isEmpty()) { // Check for a valid EstNO
	                Optional<EstimationDetails> existingRecord = estimationDetailsRepository.findById(id);
	                
	                if (existingRecord.isPresent()) {
	                    // Update existing record
	                    System.out.println("existingRecord found");
	                    EstimationDetails estDetails = existingRecord.get();

	                    // Update fields with the new data from `newDetails`
	                    estDetails.setEstNO(newDetails.getEstNO());
	                    estDetails.setCustomerName(newDetails.getCustomerName());
	                    estDetails.setEstimationProcessDate(newDetails.getEstimationProcessDate());
	                    estDetails.setRepAttd(newDetails.getRepAttd());
	                    estDetails.setRepAccount(newDetails.getRepAccount());
	                    estDetails.setBillingAddress(newDetails.getBillingAddress());
	                    estDetails.setDeliveryAddress(newDetails.getDeliveryAddress());
	                    estDetails.setCustomerCity(newDetails.getCustomerCity());
	                    estDetails.setCustomerPinCode(newDetails.getCustomerPinCode());
	                    estDetails.setCustomerPhone(newDetails.getCustomerPhone());
	                    estDetails.setCustomerEmail(newDetails.getCustomerEmail());
	                    estDetails.setDeliveryCity(newDetails.getDeliveryCity());
	                    estDetails.setDeliveryPinCode(newDetails.getDeliveryPinCode());
	                    estDetails.setWarranty(newDetails.getWarranty());
	                    estDetails.setPanAndGst(newDetails.getPanAndGst());
	                    estDetails.setTotalProduct(newDetails.getTotalProduct());
	                    estDetails.setRef(newDetails.getRef());
	                    estDetails.setRemarks(newDetails.getRemarks());
	                    estDetails.setItsHaveDiscount(newDetails.getItsHaveDiscount());
	                    estDetails.setDiscountEstimate(newDetails.getDiscountEstimate());
	                    estDetails.setDemoPieceEstimate(newDetails.getDemoPieceEstimate());
	                    estDetails.setStockClearanceEstimate(newDetails.getStockClearanceEstimate());
	                    estDetails.setDiscountAmount(newDetails.getDiscountAmount());
	                    estDetails.setGst(newDetails.getGst());
	                    estDetails.setDeliveryAddress(newDetails.getDeliveryAddress());
	                    estDetails.setTotalAmount(newDetails.getTotalAmount());
	                    estDetails.setRegisterStatus(newDetails.getRegisterStatus());
	                    estDetails.setCreatedDate(newDetails.getCreatedDate());
	                    estDetails.setCreatedBy(newDetails.getCreatedBy());

	                    // Save updated record
	                    estimationDetailsRepository.save(estDetails);
	                    vResponse = "{\"status\":\"true\"}";
	                    
	                    // If status is "Convert To Order", create a new order
	                    if (newDetails.getRegisterStatus().equalsIgnoreCase("Convert To Order")) {
	                        try {
	                            OrderDetails orderDetails = new OrderDetails();
	                            orderDetails.setId(UUID.randomUUID());
	                            orderDetails.seteNo("");  // Set fields according to your logic
	                            orderDetails.setEstNo(newDetails.getEstNO());
	                            orderDetails.setOrderNo(orderDetailsRepository.generateOrderSequence());
	                            orderDetails.setSoNo("");
	                            orderDetails.setDdNo("");
	                            orderDetails.setCustomerName(newDetails.getCustomerName());
	                            orderDetails.setOrderProcessDate(new Timestamp(System.currentTimeMillis())); // Proper timestamp
	                            orderDetails.setRepCode(newDetails.getRepAttd());
	                            orderDetails.setBillingName("");  // Set appropriate values or keep blank
	                            orderDetails.setBillingAddress(newDetails.getBillingAddress());
	                            orderDetails.setCustomerCity(newDetails.getCustomerCity());
	                            orderDetails.setCustomerPinCode(newDetails.getCustomerPinCode());
	                            orderDetails.setCustomerPhone(newDetails.getCustomerPhone());
	                            orderDetails.setCustomerEmail(newDetails.getCustomerEmail());
	                            orderDetails.setDeliveryCity(newDetails.getDeliveryCity());
	                            orderDetails.setDemoPlan("");
	                            orderDetails.setPaymentCharges("");
	                            orderDetails.setPaymentTermDate(null);  // Assuming no payment date
	                            orderDetails.setWarranty(newDetails.getWarranty());
	                            orderDetails.setPanAndGst(newDetails.getPanAndGst());
	                            orderDetails.setDemoDate(null);
	                            orderDetails.setDeliveryAddress(newDetails.getDeliveryAddress());
	                            orderDetails.setDeliveryPinCode(newDetails.getDeliveryPinCode());
	                            orderDetails.setExpectedDate(null);
	                            orderDetails.setShipModeName("");
	                            orderDetails.setRemarks(newDetails.getRemarks());
	                            orderDetails.setItsHaveDiscount(newDetails.getItsHaveDiscount());
	                            orderDetails.setDiscountEstimate(newDetails.getDiscountEstimate());
	                            orderDetails.setDemoPieceEstimate(newDetails.getDemoPieceEstimate());
	                            orderDetails.setStockClearanceEstimate(newDetails.getStockClearanceEstimate());
	                            orderDetails.setDiscountAmount(newDetails.getDiscountAmount());
	                            orderDetails.setTotalProductAmount(newDetails.getTotalAmount());
	                            orderDetails.setGst(newDetails.getGst());
	                            orderDetails.setDeliveryCharges(newDetails.getDeliveryCharges());
	                            orderDetails.setTotalAmount(newDetails.getTotalAmount());
	                            orderDetails.setLessAdvance("");
	                            orderDetails.setBalance("");
	                            orderDetails.setRegisterStatus(newDetails.getRegisterStatus());

	                            // Save the order
	                            orderDetailsRepository.save(orderDetails);
	                        } catch (Exception e4) {
	                            e4.printStackTrace();
	                        }
	                    }

	                } else {
	                    System.out.println("New record - Creating a new estimation");
	                    newDetails.setId(id);  // Ensure ID is set
	                    newDetails.setEstNO(estimationDetailsRepository.generateEstimationSequence());
	                    estimationDetailsRepository.save(newDetails);
	                    vResponse = "{\"status\":\"true\"}";
	                }
	            } else {
	                System.out.println("EstNO is empty or null");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
	        }
	        System.out.println("VResponse :::" + vResponse);
	        return vResponse;
	    }

		
		@RequestMapping(value = "/fsm/editEstimationDetails", method = RequestMethod.POST, consumes="application/json")
		public String editEstimationDetails(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/editEstimationDetails::::::::::::::::"+payload);			
				JSONObject jObj = new JSONObject(payload);
				String idString = jObj.getString("ID");	
				UUID id = UUID.fromString(idString);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Optional<EstimationDetails> existingDetailsRecord = estimationDetailsRepository.findById(id);
				if(existingDetailsRecord.isPresent()) {
					EstimationDetails estDetails = existingDetailsRecord.get();
					ObjectMapper mapper = new ObjectMapper();
					mapper.setDateFormat(sdf);
					String sourceString = mapper.writeValueAsString(estDetails);
					
					List<EstimationProductDetails> estProductDetailsList = estimationProductDetailsRepository.findByReferenceId(id.toString());
					String estProductSourceString = mapper.writeValueAsString(estProductDetailsList);				
					vResponse =  "{\"status\":\"true\",\"data\":"+sourceString+",\"estProductData\":"+estProductSourceString+"}";					
				}else {
					vResponse =  "{\"status\":\"false\"}";
				}										
				System.out.println(vResponse);
			}catch(Exception e4) {
				e4.printStackTrace();
			}
		    return vResponse;
		}
		
		@RequestMapping(value = "/fsm/deleteEstimationDetails", method = RequestMethod.POST, consumes="application/json")
		public String deleteEstimationDetails(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/deleteEstimationDetails::::::::::"+payload);
				JSONObject jObj = new JSONObject(payload);
				String idString = jObj.getString("ID");			
				UUID id = UUID.fromString(idString);			
				Optional<EstimationDetails> existingDetailsRecord = estimationDetailsRepository.findById(id);			
				if(existingDetailsRecord.isPresent()){					
					EstimationDetails estDetails = existingDetailsRecord.get();
					estimationDetailsRepository.delete(estDetails);	
					
					List<EstimationProductDetails> estProductDetailsList = estimationProductDetailsRepository.findByReferenceId(id.toString());
					if(estProductDetailsList.size() > 0) {
						estimationProductDetailsRepository.deleteAll(estProductDetailsList);
					}
					vResponse =  "{\"status\":\"true\"}";
				}
				System.out.println("vResponse::::"+vResponse);
			}catch(Exception e4) {
				e4.printStackTrace();			
			}
		    return vResponse;
		}
		
		/******************************************************update****************************************************/
		@RequestMapping(value = "/fsm/updateEstimationProductsDetails", method = RequestMethod.POST, consumes = "application/json")
		public String updateEstimationProductsDetails(@RequestBody String payload) {
		    String vResponse = "{\"status\":\"false\"}";
		    try {
		        System.out.println("/fsm/updateEstimationProductsDetails:::::::" + payload);		        
		        ObjectMapper mapper = new ObjectMapper();
		        List<EstimationProductDetails> newDetailsList = mapper.readValue(payload, 
		                new TypeReference<List<EstimationProductDetails>>() {});
		        for(EstimationProductDetails newDetails: newDetailsList) {
		        	UUID id = newDetails.getId();	        
			        if (id != null) {	            
			            Optional<EstimationProductDetails> existingRecord = estimationProductDetailsRepository.findById(id);
			            if (existingRecord.isPresent()) {	  
			            	System.out.println("existingRecord");
			            	EstimationProductDetails estProductDetails = existingRecord.get();
			            	estProductDetails.setProductCode(newDetails.getProductCode());
			            	estProductDetails.setProductDetails(newDetails.getProductDetails());
			            	estProductDetails.setQty(newDetails.getQty());
			            	estProductDetails.setReferenceId(newDetails.getReferenceId());
			            	estProductDetails.setTax(newDetails.getTax());
			            	estProductDetails.setUnitPrice(newDetails.getUnitPrice());
			            	estProductDetails.setTotal(newDetails.getTotal());
			            	estimationProductDetailsRepository.save(estProductDetails);			            	
			            }
			        } else {
			        	System.out.println("newRecord");
			        	newDetails.setId(UUID.randomUUID());		        	
			        	estimationProductDetailsRepository.save(newDetails);
			            
			        }
		        }
		        vResponse = "{\"status\":\"true\"}";
		    } catch (Exception e) {
		        e.printStackTrace();
		        vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
		    }
		    System.out.println("VResponse :::" + vResponse);
		    return vResponse;
		}
		
		@RequestMapping(value = "/fsm/deleteEstimationProductsDetails", method = RequestMethod.POST, consumes="application/json")
		public String deleteEstimationProductsDetails(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/deleteEstimationProductsDetails::::::::::"+payload);
				JSONObject jObj = new JSONObject(payload);
				String idString = jObj.getString("ID");			
				UUID id = UUID.fromString(idString);			
				Optional<EstimationProductDetails> estProductDetailsRecord = estimationProductDetailsRepository.findById(id);			
				if(estProductDetailsRecord.isPresent()){					
					EstimationProductDetails estProductDetails = estProductDetailsRecord.get();
					estimationProductDetailsRepository.delete(estProductDetails);						
					vResponse =  "{\"status\":\"true\"}";
				}
				System.out.println("vResponse::::"+vResponse);
			}catch(Exception e4) {
				e4.printStackTrace();			
			}
		    return vResponse;
		}
	    
		@RequestMapping(value = "/fsm/getOrderDetailsList", method = RequestMethod.POST, consumes="application/json")
		public String getOrderDetailsList(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/getOrderDetailsList:::::::");
				JSONObject jObj = new JSONObject(payload);
				String id = jObj.getString("ID");
				System.out.println(id);
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
				ObjectMapper mapper = new ObjectMapper();
				List<OrderDetails> detailsList = orderDetailsRepository.findAll();
				mapper.setDateFormat(sdf);
				String sourceString = mapper.writeValueAsString(detailsList);
				vResponse = "{\"status\":\"true\",\"data\":"+sourceString+"}";
				System.out.println(sourceString);
			}catch(Exception e4) {
				e4.printStackTrace();
			}
		    return vResponse;
		}
		
		/******************************************************update****************************************************/
		@RequestMapping(value = "/fsm/updateOrderDetails", method = RequestMethod.POST, consumes = "application/json")
		public String updateOrderDetails(@RequestBody String payload) {
		    String vResponse = "{\"status\":\"false\"}";
		    try {
		        System.out.println("/fsm/updateOrderDetails:::::::" + payload);	        
		        ObjectMapper mapper = new ObjectMapper();
		        OrderDetails newDetails = mapper.readValue(payload, OrderDetails.class);	        
		        UUID id = newDetails.getId();	        
		        if (!newDetails.getOrderNo().equalsIgnoreCase("")) {	            
		            Optional<OrderDetails> existingRecord = orderDetailsRepository.findById(newDetails.getId());
		            if (existingRecord.isPresent()) {		               
		                OrderDetails orderDetails = existingRecord.get();
		                orderDetails.seteNo(newDetails.geteNo());
		                orderDetails.setEstNo(newDetails.getEstNo());
		                orderDetails.setOrderNo(newDetails.getOrderNo());
		                orderDetails.setSoNo(newDetails.getSoNo());
		                orderDetails.setDdNo(newDetails.getDdNo());
		                orderDetails.setCustomerName(newDetails.getCustomerName());
		                orderDetails.setOrderProcessDate(newDetails.getOrderProcessDate());
		                orderDetails.setRepCode(newDetails.getRepCode());
		                orderDetails.setBillingName(newDetails.getBillingName());
		                orderDetails.setBillingAddress(newDetails.getBillingAddress());
		                orderDetails.setCustomerCity(newDetails.getCustomerCity());
		                orderDetails.setCustomerPinCode(newDetails.getCustomerPinCode());
		                orderDetails.setCustomerPhone(newDetails.getCustomerPhone());
		                orderDetails.setCustomerEmail(newDetails.getCustomerEmail());
		                orderDetails.setDeliveryCity(newDetails.getDeliveryCity());
		                orderDetails.setDemoPlan(newDetails.getDemoPlan());
		                orderDetails.setPaymentCharges(newDetails.getPaymentCharges());
		                orderDetails.setPaymentTermDate(newDetails.getPaymentTermDate());
		                orderDetails.setWarranty(newDetails.getWarranty());
		                orderDetails.setPanAndGst(newDetails.getPanAndGst());
		                orderDetails.setDemoDate(newDetails.getDemoDate());
		                orderDetails.setDeliveryAddress(newDetails.getDeliveryAddress());
		                orderDetails.setDeliveryPinCode(newDetails.getDeliveryPinCode());
		                orderDetails.setExpectedDate(newDetails.getExpectedDate());
		                orderDetails.setShipModeName(newDetails.getShipModeName());
		                orderDetails.setRemarks(newDetails.getRemarks());
		                orderDetails.setItsHaveDiscount(newDetails.getItsHaveDiscount());
		                orderDetails.setDiscountEstimate(newDetails.getDiscountEstimate());
		                orderDetails.setDemoPieceEstimate(newDetails.getDemoPieceEstimate());
		                orderDetails.setStockClearanceEstimate(newDetails.getStockClearanceEstimate());
		                orderDetails.setDiscountAmount(newDetails.getDiscountAmount());
		                orderDetails.setTotalProductAmount(newDetails.getTotalProductAmount());
		                orderDetails.setGst(newDetails.getGst());
		                orderDetails.setDeliveryCharges(newDetails.getDeliveryCharges());
		                orderDetails.setTotalAmount(newDetails.getTotalAmount());
		                orderDetails.setLessAdvance(newDetails.getLessAdvance());
		                orderDetails.setBalance(newDetails.getBalance());
		                orderDetails.setRegisterStatus(newDetails.getRegisterStatus());

		                orderDetailsRepository.save(orderDetails);
		                vResponse = "{\"status\":\"true\"}";
		            }else {
			        	System.out.println("newRecord");
			        	newDetails.setId(UUID.randomUUID());	
			        	newDetails.setOrderNo(orderDetailsRepository.generateOrderSequence());
			        	orderDetailsRepository.save(newDetails);
			        	vResponse = "{\"status\":\"true\"}";
			        }
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		        vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
		    }
		    System.out.println("VResponse :::" + vResponse);
		    return vResponse;
		}
		
		@RequestMapping(value = "/fsm/editOrderDetails", method = RequestMethod.POST, consumes="application/json")
		public String editOrderDetails(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/editOrderDetails::::::::::::::::"+payload);			
				JSONObject jObj = new JSONObject(payload);
				String idString = jObj.getString("ID");	
				UUID id = UUID.fromString(idString);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Optional<OrderDetails> existingDetailsRecord = orderDetailsRepository.findById(id);
				if(existingDetailsRecord.isPresent()) {
					OrderDetails orderDetails = existingDetailsRecord.get();
					ObjectMapper mapper = new ObjectMapper();
					mapper.setDateFormat(sdf);
					String sourceString = mapper.writeValueAsString(orderDetails);
					
					List<OrderProductDetails> ordProductDetailsList = orderProductDetailsRepository.findByReferenceId(id.toString());
					String estProductSourceString = mapper.writeValueAsString(ordProductDetailsList);				
					vResponse =  "{\"status\":\"true\",\"data\":"+sourceString+",\"ordProductData\":"+estProductSourceString+"}";					
				}else {
					vResponse =  "{\"status\":\"false\"}";
				}										
				System.out.println(vResponse);
			}catch(Exception e4) {
				e4.printStackTrace();
			}
		    return vResponse;
		}
		@RequestMapping(value = "/fsm/deleteOrderDetails", method = RequestMethod.POST, consumes="application/json")
		public String deleteOrderDetails(@RequestBody String payload) {
		String vResponse =  "{\"status\":\"false\"}";
		try {
			System.out.println("/fsm/deleteOrderDetails::::::::::"+payload);
			JSONObject jObj = new JSONObject(payload);
			String idString = jObj.getString("ID");			
			UUID id = UUID.fromString(idString);			
			Optional<OrderDetails> existingDetailsRecord = orderDetailsRepository.findById(id);			
			if(existingDetailsRecord.isPresent()){					
				OrderDetails ordDetails = existingDetailsRecord.get();
				orderDetailsRepository.delete(ordDetails);	
				
				List<OrderProductDetails> ordProductDetailsList = orderProductDetailsRepository.findByReferenceId(id.toString());
				if(ordProductDetailsList.size() > 0) {
					orderProductDetailsRepository.deleteAll(ordProductDetailsList);
				}
				vResponse =  "{\"status\":\"true\"}";
			}
			System.out.println("vResponse::::"+vResponse);
		}catch(Exception e4) {
			e4.printStackTrace();			
		}
	    return vResponse;
	}
		
		/******************************************************update****************************************************/
		@RequestMapping(value = "/fsm/updateOrderProductsDetails", method = RequestMethod.POST, consumes = "application/json")
		public String updateOrderProductsDetails(@RequestBody String payload) {
		    String vResponse = "{\"status\":\"false\"}";
		    try {
		        System.out.println("/fsm/updateOrderProductsDetails:::::::" + payload);		        
		        ObjectMapper mapper = new ObjectMapper();
		        List<OrderProductDetails> newDetailsList = mapper.readValue(payload, 
		                new TypeReference<List<OrderProductDetails>>() {});
		        for(OrderProductDetails newDetails: newDetailsList) {
		        	UUID id = newDetails.getId();	        
			        if (id != null) {	            
			            Optional<OrderProductDetails> existingRecord = orderProductDetailsRepository.findById(id);
			            if (existingRecord.isPresent()) {	  
			            	System.out.println("existingRecord");
			            	OrderProductDetails ordProductDetails = existingRecord.get();
			            	ordProductDetails.setProductCode(newDetails.getProductCode());
			            	ordProductDetails.setProductType(newDetails.getProductType());
			            	ordProductDetails.setProductDetails(newDetails.getProductDetails());
			            	ordProductDetails.setQty(newDetails.getQty());
			            	ordProductDetails.setReferenceId(newDetails.getReferenceId());
			            	ordProductDetails.setTax(newDetails.getTax());
			            	ordProductDetails.setUnitPrice(newDetails.getUnitPrice());
			            	ordProductDetails.setTotal(newDetails.getTotal());
			            	orderProductDetailsRepository.save(ordProductDetails);			            	
			            }
			        } else {
			        	System.out.println("newRecord");
			        	newDetails.setId(UUID.randomUUID());		        	
			        	orderProductDetailsRepository.save(newDetails);
			            
			        }
		        }
		        vResponse = "{\"status\":\"true\"}";
		    } catch (Exception e) {
		        e.printStackTrace();
		        vResponse = "{\"status\":\"false\", \"message\":\"An error occurred.\"}";
		    }
		    System.out.println("VResponse :::" + vResponse);
		    return vResponse;
		}
		
		@RequestMapping(value = "/fsm/deleteOrderProductsDetails", method = RequestMethod.POST, consumes="application/json")
		public String deleteOrderProductsDetails(@RequestBody String payload) {
			String vResponse =  "{\"status\":\"false\"}";
			try {
				System.out.println("/fsm/deleteOrderProductsDetails::::::::::"+payload);
				JSONObject jObj = new JSONObject(payload);
				String idString = jObj.getString("ID");			
				UUID id = UUID.fromString(idString);			
				Optional<OrderProductDetails> ordProductDetailsRecord = orderProductDetailsRepository.findById(id);			
				if(ordProductDetailsRecord.isPresent()){					
					OrderProductDetails estProductDetails = ordProductDetailsRecord.get();
					orderProductDetailsRepository.delete(estProductDetails);						
					vResponse =  "{\"status\":\"true\"}";
				}
				System.out.println("vResponse::::"+vResponse);
			}catch(Exception e4) {
				e4.printStackTrace();			
			}
		    return vResponse;
		}
	    
}
