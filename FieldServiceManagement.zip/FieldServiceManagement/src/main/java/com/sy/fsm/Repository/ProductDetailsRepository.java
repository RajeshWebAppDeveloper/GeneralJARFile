package com.sy.fsm.Repository;


import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.sy.fsm.Model.ProductDetails;








@Repository
public interface ProductDetailsRepository extends JpaRepository<ProductDetails,UUID>  {
	 
	@Query(value = "SELECT generate_product_sequence()",nativeQuery = true)
	String generateProductSequence();
	

	@Query(value = "SELECT * from product_details WHERE product_name = :productName",nativeQuery = true)
	Optional<ProductDetails> findByProductName(String productName);
	
	@Query(value = "SELECT * from product_details WHERE product_id = :productId",nativeQuery = true)
	Optional<ProductDetails> findByProductId(String productId);

}













