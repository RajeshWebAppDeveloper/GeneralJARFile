package com.sy.fsm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FieldServiceManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FieldServiceManagementApplication.class, args);
	}

}
