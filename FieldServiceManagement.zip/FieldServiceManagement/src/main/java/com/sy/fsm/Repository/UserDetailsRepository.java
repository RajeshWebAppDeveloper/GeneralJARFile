package com.sy.fsm.Repository;


import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sy.fsm.Model.UserDetails;

@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails, UUID>  {
	
	@Query(value = "SELECT * FROM user_details WHERE role_name= :roleName", nativeQuery = true)
	Optional<UserDetails> findByRoleName(String roleName);
	
	@Query(value = "SELECT count(*) FROM user_details",nativeQuery = true)
	int getNumberOfuserDetails();
	
	@Query(value = "SELECT * FROM user_details WHERE user_name= :userName", nativeQuery = true)
	Optional<UserDetails> findByUserName(String userName);
	
}
