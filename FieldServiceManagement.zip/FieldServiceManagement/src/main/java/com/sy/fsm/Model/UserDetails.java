package com.sy.fsm.Model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "admin_software_user_details")
public class UserDetails {
	@Id
	@Column(name = "id")
	@JsonProperty("ID")
	private UUID id;
	
	@Column(name = "user_id")
	@JsonProperty("User ID")
	private String userId;
	
	@Column(name = "user_name")
	@JsonProperty("User Name")
	private String userName;
	 
	@Column(name = "password")
	@JsonProperty("Password")
	private String password;
	 
	@Column(name = "email_id")
	@JsonProperty("Email ID")
	private String emailId;
	 
	@Column(name = "mobile_no")
	@JsonProperty("Mobile No")
	private String mobileNO;
	 
	@Column(name = "role_name")
	@JsonProperty("Role Name")
	private String roleName;
	 
	@Column(name = "branch")
	@JsonProperty("Branch")
	private String branch;

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNO() {
		return mobileNO;
	}

	public void setMobileNO(String mobileNO) {
		this.mobileNO = mobileNO;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public UserDetails(UUID id, String userId, String userName, String password, String emailId, String mobileNO,
			String roleName, String branch) {
		super();
		this.id = id;
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.emailId = emailId;
		this.mobileNO = mobileNO;
		this.roleName = roleName;
		this.branch = branch;
	}

	public UserDetails() {
		super();
	}

		
}
