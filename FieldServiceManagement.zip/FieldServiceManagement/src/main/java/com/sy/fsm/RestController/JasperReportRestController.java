package com.sy.fsm.RestController;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sy.fsm.Model.EstimationDetails;
import com.sy.fsm.Repository.EstimationDetailsRepository;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

@org.springframework.web.bind.annotation.RestController
public class JasperReportRestController {
	
	@Autowired
	EstimationDetailsRepository estimationDetailsRepository;
	
	@PostMapping("/fsm/exportJasperReportInEstimation")
    public ResponseEntity<String> exportJasperReportInEstimation(@RequestBody String payload) {
    	 try {
    		 System.out.println("/fsm/exportJasperReportInEstimation:::::");
    		 JSONObject jobj = new JSONObject(payload); 
    		 String idString = jobj.getString("ID");
    		 String reportType = jobj.getString("Report Type");
    		 UUID id = UUID.fromString(idString);
    		 ObjectMapper mapper = new ObjectMapper();
    		 Optional<EstimationDetails> existingRecord = estimationDetailsRepository.findById(id);
    		 if(existingRecord.isPresent()) {
    			EstimationDetails estDetails = existingRecord.get();
    			@SuppressWarnings("unchecked")
 				Map<String, Object> parameters = mapper.convertValue(estDetails, Map.class);
    			String jasperFilePath = "src/main/resources/Reports/Enquiry.jasper";
    			 
    			 if(reportType.equalsIgnoreCase("pdf")) {
    				 InputStream jasperStream = new FileInputStream(jasperFilePath);
                     JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
                     					
                     
                     JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters,new JREmptyDataSource());

                     String pdfFilePath = "C:/Users/Lenovo/JaspersoftWorkspace/MyReports/output1.pdf";
                     JasperExportManager.exportReportToPdfFile(jasperPrint, pdfFilePath);
    			 }else if(reportType.equalsIgnoreCase("excel")) {
    				 	InputStream jasperStream = new FileInputStream(jasperFilePath);
    		            JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
    		            
    		            
    		                     
    		            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());

    		            String excelFilePath = "C:/Users/Lenovo/JaspersoftWorkspace/MyReports/output1.xlsx";

    		            JRXlsxExporter exporter = new JRXlsxExporter();
    		            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
    		            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(excelFilePath));

    		            SimpleXlsxReportConfiguration reportConfig = new SimpleXlsxReportConfiguration();
    		            reportConfig.setOnePagePerSheet(false);  
    		            reportConfig.setRemoveEmptySpaceBetweenRows(true);  

    		            exporter.setConfiguration(reportConfig);
    		            exporter.exportReport();  

    			 }
    		 }
             
             return ResponseEntity.ok("PDF Report generated successfully.");
         } catch (Exception e) {
             e.printStackTrace();
             return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
         }       
    }
    
   
    @GetMapping("/excel")
    public ResponseEntity<String> generateExcelReport() {
        try {
            String jasperFilePath = "src/main/resources/Reports/Enquiry.jasper";
            InputStream jasperStream = new FileInputStream(jasperFilePath);
            JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
            
            Map<String, Object> parameters = new HashMap<>();
                     
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());

            String excelFilePath = "C:/Users/Lenovo/JaspersoftWorkspace/MyReports/output1.xlsx";

            JRXlsxExporter exporter = new JRXlsxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(excelFilePath));

            SimpleXlsxReportConfiguration reportConfig = new SimpleXlsxReportConfiguration();
            reportConfig.setOnePagePerSheet(false);  
            reportConfig.setRemoveEmptySpaceBetweenRows(true);  

            exporter.setConfiguration(reportConfig);
            exporter.exportReport();  

            return ResponseEntity.ok("Excel Report generated successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

}
