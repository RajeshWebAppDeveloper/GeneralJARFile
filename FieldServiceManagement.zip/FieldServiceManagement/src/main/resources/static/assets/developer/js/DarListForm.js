
function getDarListForm(){
    var form = `
            <div class="content">
				<div class="row mb-3">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">Dars Details</h4>
                    </div>
                    <div class="col-sm-8 col-9 text-end m-b-20">
						<a href="#" class="btn btn-primary float-right btn-rounded" onclick="getDarList('dars_list_form')"><i class="fas fa-refresh"></i> Refresh</a>
                        <a href="#" class="btn btn-primary float-right btn-rounded" onclick="showDarEntryForm('add')"><i class="fas fa-plus"></i> Add Dar</a>
                    </div>
                </div> 	
                <div class="buy-form">	                	
	                <div class="col-12">
						<div class="card">														
							<div class="card-body">
								<div class="table-responsive" id="dar_list_table_container" class="dt-container dt-bootstrap5 dt-empty-footer"></div>					
							</div>
						</div>
					</div>
            	</div>
            </div> 
			
			`;
    return form;
};


function showDarListForm(backMethod){
    try{
		
        hideAllLayer();	
        var containerId = "dar_list_form";         
        document.getElementById(containerId).style.display = "block";
		if(backMethod != "true"){		
			getDarList(containerId);	
		}		
    }catch(exp){
        alert(exp);
		toastr.error(exp,"Error", {closeButton: !0,tapToDismiss: !1});
    }
};


async function getDarList(containerId){
    var jsonObj = JSON.parse("{}");
    jsonObj['ID'] = "all";      	
    let url = "/fsm/getDarDetailsList";
	let itemName= "getDarDetailsList";
    getDataFromServicePoint(url,jsonObj)
        .then(async data => await populateDarListVResponse(data,containerId)) 
        .catch(error => handleError(itemName,error));
};


async function populateDarListVResponse(vResponse,containerId){		
    if(vResponse.status == "true"){
		var dataArray = vResponse.data;		
		var editFunction = "editDarDetails(this)";
		var deleteFunction = "deleteDarDetails(this)";
		var tableId = containerId+"_table_id";
		document.getElementById("dar_list_table_container").innerHTML = await createDataTable(vResponse,editFunction,deleteFunction,tableId);
		if(dataArray.length > 0){
			await $("#"+tableId).DataTable({				
			                "searching": true,  
			                "paging": true,     
			                "info": true,       
			                "lengthChange": true,
			                "autoWidth": false,  
							"pageLength": 10, 
			                "columnDefs": [
			                    { "orderable": false, "targets": -1 }
								,{
					             "targets": [0], 
								 "className": "hidden-column" 
					        	} 
			                ]		
			         });						
		}			        	 	      	
	}
};



