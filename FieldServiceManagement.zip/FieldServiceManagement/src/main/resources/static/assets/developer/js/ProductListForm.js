
function getProductListForm(){
    var form = `
            <div class="content">
				<div class="row mb-3">
                    <div class="col-sm-4 col-3">
                        <h2 class="page-title">Products Details</h2>
                    </div>
                    <div class="col-sm-8 col-9 text-end m-b-20">
						<a href="#" class="btn btn-primary float-right btn-rounded" onclick="getProductList('products_list_form')"><i class="fas fa-refresh"></i> Refresh</a>
                        <a href="#" class="btn btn-primary float-right btn-rounded" onclick="showProductEntryForm('add')"><i class="fas fa-plus"></i> Add Product</a>
                    </div>
                </div> 	
                <div class="buy-form">	                	
	                <div class="col-12">
						<div class="card">														
							<div class="card-body">
								<div class="table-responsive" id="product_list_table_container" class="dt-container dt-bootstrap5 dt-empty-footer"></div>					
							</div>
						</div>
					</div>
            	</div>
            </div> 
			
			`;
    return form;
};


function showProductListForm(backMethod){
    try{
		
        hideAllLayer();	
        var containerId = "product_list_form";         
        document.getElementById(containerId).style.display = "block";
		if(backMethod != "true"){		
			getProductList(containerId);	
		}		
    }catch(exp){
        alert(exp);
		toastr.error(exp,"Error", {closeButton: !0,tapToDismiss: !1});
    }
};


async function getProductList(containerId){
    var jsonObj = JSON.parse("{}");
    jsonObj['ID'] = "all";      	
    let url = "/fsm/getProductDetailsList";
	let itemName= "getProductDetailsList";
    getDataFromServicePoint(url,jsonObj)
        .then(async data => await populateProductListVResponse(data,containerId)) 
        .catch(error => handleError(itemName,error));
};


async function populateProductListVResponse(vResponse,containerId){		
    if(vResponse.status == "true"){
		var dataArray = vResponse.data;		
		var editFunction = "editProductDetails(this)";
		var deleteFunction = "deleteProductDetails(this)";
		var tableId = containerId+"_table_id";
		document.getElementById("product_list_table_container").innerHTML = await createDataTable(vResponse,editFunction,deleteFunction,tableId);
		if(dataArray.length > 0){
			await $("#"+tableId).DataTable({				
			                "searching": true,  
			                "paging": true,     
			                "info": true,       
			                "lengthChange": true,
			                "autoWidth": false,  
							"pageLength": 10, 
			                "columnDefs": [
			                    { "orderable": false, "targets": -1 }
								,{
					             "targets": [0], 
								 "className": "hidden-column" 
					        	} 
			                ]		
			         });						
		}			        	 	      	
	}
};


