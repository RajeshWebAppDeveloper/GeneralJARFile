
function getOrderListForm(){
    var form = `
            <div class="content">
				<div class="row mb-3">
                    <div class="col-sm-4 col-3">
                        <h2 class="page-title">Orders Details</h2>
                    </div>
                    <div class="col-sm-8 col-9 text-end m-b-20">
						<a href="#" class="btn btn-primary float-right btn-rounded" onclick="getOrderList('orders_list_form')"><i class="fas fa-refresh"></i> Refresh</a>
                        <a href="#" class="btn btn-primary float-right btn-rounded" onclick="showOrderEntryForm('add')"><i class="fas fa-plus"></i> Add Order</a>
                    </div>
                </div> 	
                <div class="buy-form">	                	
	                <div class="col-12">
						<div class="card">														
							<div class="card-body">
								<div class="table-responsive" id="order_list_table_container" class="dt-container dt-bootstrap5 dt-empty-footer"></div>					
							</div>
						</div>
					</div>
            	</div>
            </div> 
			
			`;
    return form;
};


function showOrderListForm(backMethod){
    try{
		
        hideAllLayer();	
        var containerId = "order_list_form";         
        document.getElementById(containerId).style.display = "block";
		if(backMethod != "true"){		
			getOrderList(containerId);	
		}		
    }catch(exp){
        alert(exp);
		toastr.error(exp,"Error", {closeButton: !0,tapToDismiss: !1});
    }
};


async function getOrderList(containerId){
    var jsonObj = JSON.parse("{}");
    jsonObj['ID'] = "all";      	
    let url = "/fsm/getOrderDetailsList";
	let itemName= "getOrderDetailsList";
    getDataFromServicePoint(url,jsonObj)
        .then(async data => await populateOrderListVResponse(data,containerId)) 
        .catch(error => handleError(itemName,error));
};


async function populateOrderListVResponse(vResponse,containerId){		
    if(vResponse.status == "true"){
		var dataArray = vResponse.data;		
		var editFunction = "editOrderDetails(this)";
		var deleteFunction = "deleteOrderDetails(this)";
		var tableId = containerId+"_table_id";
		document.getElementById("order_list_table_container").innerHTML = await createDataTable(vResponse,editFunction,deleteFunction,tableId);
		if(dataArray.length > 0){
			await $("#"+tableId).DataTable({				
			                "searching": true,  
			                "paging": true,     
			                "info": true,       
			                "lengthChange": true,
			                "autoWidth": false,  
							"pageLength": 10, 
			                "columnDefs": [
			                    { "orderable": false, "targets": -1 }
								,{
					             "targets": [0], 
								 "className": "hidden-column" 
					        	} 
			                ]		
			         });						
		}			        	 	      	
	}
};



