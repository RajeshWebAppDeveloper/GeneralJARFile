async function getUserRightsObjectByRoleName(){
    var jsonObj = {};
    jsonObj['Role Name'] = logginerRoleName;
    var menuContainer = document.getElementById("sidebar-menu");
    let url = "/RentARide/getUserRightsObjectByRoleName";
    let itemName = "getUserRightsObjectByRoleName";

    try {
        let data = await getDataFromServicePoint(url, jsonObj);
        await getProjectMenuFeatures(menuContainer, data);
    } catch (error) {
        handleError(itemName, error);
    }
};

async function getProjectMenuFeatures(parentElement,vResponseObj){
	if(vResponseObj.status == "true"){
		var dataObj = vResponseObj.data;
		var rightsTreeStructureObjStr = dataObj['Rights Tree Structure'];
		var menuNameJsonObj = JSON.parse(rightsTreeStructureObjStr);
		var menuIconJsonObj = {
		    "Dashboard": "fa fa-bar-chart",
		    "Master": "fa fa-user-circle",
		    "User": "fa fa-user-check",
		    "User Creation": "fa fa-user-plus",
		    "User Rights": "fa fa-user-cog",
		    "Categories": "fa fa-clone",
		    "Offer": "fa fa-donate",
		    "Packages": "fa fa-briefcase",
		    "Product": "fa fa-box-open",
		    "Purchase": "fa fa-dollar",
		    "Staff": "fa fa-user-tie",
		    "Staff details": "fa fa-user-friends",
		    "Staff target": "fa fa-user-edit",
		    "Staff leave": "fa fa-user-injured",
		    "Company Setup": "fa fa-building",
		    "Appointments": "fa fa-calendar",
		    "Todays Appointments": "fa fa-hourglass-end",
		    "OverAll Appointments": "fa fa-calendar-plus",
		    "Billing": "fa fa-edit",
		    "Create Bill": "fa fa-file-upload",
		    "View Bill": "fa fa-folder-open",
		    "Customers": "fa fa-users",
		    "Enquiry": "fa fa-user-secret",
		    "Todays Enquiry": "fa fa-question-circle",
		    "OverAll Enquiry": "fa fa-question",
		    "Expenses": "fa fa-money",
		    "Reports": "fa fa-file-pdf-o",
		    "Logout": "fa fa-sign-out-alt",
		    "Customers Booking": "fa fa-book",
		    "Customers Profile": "fa fa-users",
		    "Cars Info": "fa fa-cab",
		    "Default Properties": "fa fa-check-double",
		    "Payment Rule": "fa fa-info-circle",
			"Price Plans":"fa fa-gift",
		    "Holiday Booking": "fa fa-suitcase",
		    "Multi-Day Booking": "fa fa-bookmark",
		    "Message Template": "fa fa-comments",
		    "Email Template": "fa fa-envelope",
		    "Whatsapp Template": "fab fa-whatsapp",
			"Feedback":"fa fa-comment-dots"
		};

		var menuFunctionJsonObj = {
		    "Dashboard": "showAdminDashboardForm()",                                                                    
		    "User Creation": "showUserListForm('')",
		    "User Rights": "showUserRightsListForm('')",
		    "Customers Booking": "showCustomerCarBookingDetailsListForm('')",
		    "Customers Profile": "showCustomerProfileListForm('')",
		    "Cars Info": "showRentalCarsListForm('')",                                             
		    "Default Properties": "showDefaultPropertiesListForm('')",
			"Price Plans":"showPricePlanRuleListForm('')",                                                                 
		    "Holiday Booking": "showHolidayPaymentRuleListForm('')",
		    "Multi-Day Booking": "showMultipleDayPaymentRuleListForm('')",                                    
		    "Email Template": "showEmailInfoListForm('')",
		    "Whatsapp Template": "showWhatsAppInfoListForm('')",
			"Feedback":"showCustomerFeedbackListForm('')"
		};

		await buildProjectMenu(parentElement, menuNameJsonObj, menuIconJsonObj, menuFunctionJsonObj);		
	}     
};
async function buildProjectMenu(parentElement, menuNameJsonObj, menuIconJsonObj, menuFunctionJsonObj) {
    var unorderList = document.createElement("UL");

    for (let menuName in menuNameJsonObj) {  // Use `let` to bind each menuName properly in the loop
        var list = document.createElement("LI");
        list.setAttribute("title", menuName);

        var aTag = document.createElement("A");
        aTag.setAttribute("href", "#");
		
		if(menuFunctionJsonObj[menuName] == undefined || menuFunctionJsonObj[menuName] == "undefined"){
			aTag.onclick = function(){				
				if(window.getComputedStyle(this.nextSibling).display == "none") {				
	                this.setAttribute("class", "subdrop");
	                this.nextSibling.style.display = "block";
	            }else if(window.getComputedStyle(this.nextSibling).display == "block"){					
	                this.setAttribute("class", "");
	                this.nextSibling.style.display = "none";
	            }	
			}				
		}else{
			aTag.setAttribute("onclick",menuFunctionJsonObj[menuName]);
		}		
        list.appendChild(aTag);

        var iconTag = document.createElement("I");
        iconTag.setAttribute("class", menuIconJsonObj[menuName]);
        aTag.appendChild(iconTag);

        var menuNameSpanTag = document.createElement("SPAN");
        menuNameSpanTag.innerHTML = menuName;
        aTag.appendChild(menuNameSpanTag);

        // Check if the submenu exists and is an object (to avoid infinite recursion)
        if (typeof menuNameJsonObj[menuName] === 'object' && Object.keys(menuNameJsonObj[menuName]).length > 0) {
            var menuArrowSpanTag = document.createElement("SPAN");
            menuArrowSpanTag.setAttribute("class", "menu-arrow");
            aTag.appendChild(menuArrowSpanTag);

            // Recursively build the submenu
            await buildProjectMenu(list, menuNameJsonObj[menuName], menuIconJsonObj, menuFunctionJsonObj);
        }

        unorderList.appendChild(list);
    }

    parentElement.appendChild(unorderList);
};
