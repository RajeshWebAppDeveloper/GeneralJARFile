
function createDataTable(responseData,editFunction,deleteFunction,tableId){	

	var containerObj 				= document.createElement("table");
	var containerHeaderObj 			= document.createElement("thead");
	var containerBodyObj 			= document.createElement("tbody");	

try{		
	
	containerObj.setAttribute("class","table table-striped table-bordered dt-responsive nowrap w-100 datatable dataTable no-footer");
	containerObj.setAttribute("id",tableId);
	containerHeaderObj.setAttribute("class","thead-light");		
	
	containerObj.appendChild(containerHeaderObj);
	containerObj.appendChild(containerBodyObj);		
		
	var actualData = responseData.data;
	
	
	const createRow = () =>{
		var dataRow = document.createElement("TR");			
		return dataRow;
	};

	const createColumn = (elementName,rowKey,rowValue,className) =>{				

		var rowCell = document.createElement(elementName);
		rowCell.innerHTML = rowValue;
		rowCell.setAttribute("name",rowKey);
		//rowCell.setAttribute("title",rowValue);
		if(className != ""){
			rowCell.setAttribute("class",className);	
		}
		
		return rowCell;
	};

	const dataRowActionColumn = () =>{
		var button = `<button class="btn btn-sm btn-white text-success me-2" onclick="`+editFunction+`"><i class="far fa-edit me-1"></i> Edit</button><buttonn class="btn btn-sm btn-white text-info me-2" onclick="`+deleteFunction+`"><i class="far fa-trash-alt me-1"></i> Delete</button>`;
        return button;
	};
	
	var headerArray = new Array();		
	for(var obj in actualData){
		if(actualData.hasOwnProperty(obj)){
			var dataRow = createRow();
			containerHeaderObj.appendChild(dataRow);
			var gg = 0;
			for(var prop in actualData[obj]){
	        	if(actualData[obj].hasOwnProperty(prop)){
	        		headerArray.push(prop);
	        		console.log("HEADER :"+ gg +">>>"+ headerArray[gg]);
	        		var columnData = createColumn("TH",prop,prop,"");		        		
	        		dataRow.appendChild(columnData);		        		
	        		gg++;
		        }			        
		    }
		    var columnActionData = createColumn("TH","Event Buttons","","text-end");
	        dataRow.appendChild(columnActionData);
			break;
	   }
	}
	
	var gtgt =0;				
	for(var obj in actualData){
		gtgt++;
		if(actualData.hasOwnProperty(obj)){
			var dataRow = createRow();				
			containerBodyObj.appendChild(dataRow);
			var gg=0;
			for(var prop in actualData[obj]){
	        	if(actualData[obj].hasOwnProperty(prop)){
	        		var rowData = createColumn("TD",prop,actualData[obj][prop],"");
	        		dataRow.appendChild(rowData);		        		
	        		gg++;
		        }			        
		    }
		    var actionHTML = dataRowActionColumn();
    		actionHTML = createColumn("TD","Event Buttons",actionHTML,"");
    		dataRow.appendChild(actionHTML);
		}
	}				
	
	}catch(exp){
		alert(exp);
	}

	return containerObj.outerHTML;
	
};

function searchTable(input,tableParentId) {
    var filter, tableBody, tr, td, i, txtValue;
    filter = input.value.toLowerCase();
    tableBody = document.getElementById(tableParentId).childNodes[0].childNodes[1];
    tr = tableBody.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        tr[i].style.display = "none";
        td = tr[i].getElementsByTagName('td');
        for (var j = 0; j < td.length; j++) {
            if (td[j]) {
                txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toLowerCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                    break;
                }
            }
        }
    }
};



