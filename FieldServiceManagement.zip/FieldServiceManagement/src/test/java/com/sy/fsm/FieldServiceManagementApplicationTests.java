package com.sy.fsm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FieldServiceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
